# Bio-Quantum v10 (Singularity GPU Ultra - Escalado x20)

Paquete autónomo y comprimido con el modelo entrenado a escala $\times 20$ en GPU **AMD Radeon RX 7800 XT** (16 GB GDDR6, RDNA 3, 60 Compute Units).

---

## 1. Contenido del Paquete

* **`weights_x20.bin`**: Checkpoint binario (`f32` little-endian) de las **2,048 sinapsis** ($W^E$, $W^I$) entrenadas en VRAM con cumplimiento estricto de la Ley de Dale ($W \ge 10^{-4}$, 0 violaciones).
* **`weights_x20.json`**: Representación estructurada JSON con los pesos y metadatos de la arquitectura.
* **`training_results_gpu_rx7800xt.json`**: Telemetría completa del entrenamiento masivo de 1.638M episodios.
* **`RESULTADOS_GPU_RX7800XT.md`**: Informe técnico detallado de hardware, rendimiento y análisis comparativo.
* **`src/gpu_shaders.rs`**: Shaders de cómputo en WGSL para la GPU AMD (512D Lie algebra, fasores cuánticos en $\mathbb{C}$, proyección Brenier-Lyapunov, optimizador proyectado Dale y consolidación circadiana SWR).
* **`src/gpu_engine.rs`**: Motor de Rust que gestiona la asignación de buffers en VRAM, pipelines de cómputo y sincronización asíncrona mediante `wgpu`.
* **`src/main.rs` & `Cargo.toml`**: Código fuente ejecutable para auditoría y re-entrenamiento reproducible.

---

## 2. Resumen de Métricas del Modelo x20

| Métrica | Valor Obtenido |
| :--- | :--- |
| **Episodios Entrenados** | **1,638,400 episodios** (400 lotes $\times$ 4,096) |
| **Throughput GPU** | **49,159 episodios / segundo** (~70,000,000 coords/seg) |
| **Tiempo de Cómputo** | **33.33 segundos** en AMD Radeon RX 7800 XT |
| **Nodos por Constelación** | **512 puntos** (1,024 canales 2D) |
| **Dimensión de Base de Lie** | **512D** |
| **Pérdida Final MSE** | **0.000249** |
| **Auditoría Ley de Dale** | **0 violaciones en 2,048 sinapsis** (100% compliant) |
| **Consolidación SWR** | $\Delta R = -0.00042 \ge -\varepsilon$ (olvido acotado) |

---

## 3. Instrucciones de Uso y Reproducción

Para ejecutar una auditoría o entrenar nuevamente desde este código:

```bash
# Auditar estado y compatibilidad de la GPU
cargo run --release -- gpu-audit

# Re-entrenar modelo x20 (400 lotes, 4096 batch size, 0.05 lr)
cargo run --release -- gpu-train 400 4096 0.05
```
