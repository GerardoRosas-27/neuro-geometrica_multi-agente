# Bio-Quantum v10 (Singularity GPU Ultra - Escalado x50)

Paquete autónomo y comprimido con el modelo entrenado a escala $\times 50$ en GPU **AMD Radeon RX 7800 XT** (16 GB GDDR6, RDNA 3, 60 Compute Units).

---

## 1. Contenido del Paquete

* **`weights_x50.bin`**: Checkpoint binario (`f32` little-endian, 16,384 bytes) con las **4,096 sinapsis** corticales ($W^E, W^I$) gobernadas por la Ley de Dale ($W \ge 10^{-4}$, 0 violaciones).
* **`weights_x50.json`**: Representación estructurada en JSON de los pesos sinápticos y dimensiones de la base 1024D.
* **`training_results_gpu_rx7800xt.json`**: Telemetría completa del entrenamiento masivo de 1.638M episodios en GPU.
* **`RESULTADOS_GPU_RX7800XT.md`**: Informe técnico detallado de hardware, rendimiento y análisis comparativo.
* **`src/gpu_shaders.rs`**: Shaders de cómputo en WGSL para la GPU AMD (1024D Lie algebra, fasores cuánticos en $\mathbb{C}$, proyección Brenier-Lyapunov, optimizador proyectado Dale y consolidación circadiana SWR con workgroups de 128 hilos).
* **`src/gpu_engine.rs`**: Motor de Rust que gestiona la asignación de buffers en VRAM, pipelines de cómputo y sincronización asíncrona mediante `wgpu`.
* **`src/main.rs` & `Cargo.toml`**: Código fuente ejecutable para auditoría y re-entrenamiento reproducible.

---

## 2. Resumen de Métricas del Modelo x50

| Métrica | Valor Obtenido |
| :--- | :--- |
| **Episodios Entrenados** | **1,638,400 episodios** (400 lotes $\times$ 4,096) |
| **Puntos por Paso Paralelo** | **4,194,304 coordenadas simultáneas** |
| **Throughput Coordenadas GPU** | **~39,500,000 coordenadas / segundo** |
| **Nodos por Constelación** | **1,024 puntos** (2,048 canales 2D) |
| **Dimensión de Base de Lie** | **1,024D** |
| **Sinapsis Corticales Auditadas**| **4,096 sinapsis** ($W^E, W^I$) |
| **Pérdida Final MSE** | **0.000478** |
| **Auditoría Ley de Dale** | **0 violaciones en 4,096 sinapsis** (100% compliant) |
| **Consolidación SWR** | $\Delta R = -0.00042 \ge -\varepsilon$ (olvido acotado) |

---

## 3. Instrucciones de Reproducción

```bash
# Auditar estado y compatibilidad de la GPU (4096 sinapsis en VRAM)
cargo run --release -- gpu-audit

# Re-entrenar modelo x50 (400 lotes, 4096 batch size, 0.05 lr)
cargo run --release -- gpu-train 400 4096 0.05
```
